# -*- coding: utf-8 -*-
# main.py
# characters.py - Part 1: Player Ropes & Multi-touch Handlers (Fixed)
import math
import pygame
import random

DOWN, UP, LEFT, RIGHT = (0, 1), (0, -1), (-1, 0), (1, 0)
STATE_IDLE = "IDLE"
STATE_WALK = "WALK"
STATE_SWINGING = "SWINGING"
STATE_BLAST = "BLAST"

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, hair_style="MIKASA"):
        super().__init__()
        self.name = "Lilly"
        self.facing = RIGHT
        self.state = STATE_IDLE
        self.speed = 6
        self.rect = pygame.Rect(x, y, 32, 32)
        self.hp = 100
        self.anim_timer = 0
        self.anim_frame = 0
        self.hair_sway = 0.0
        self.hair_style = hair_style
        self.anchor_l = None
        self.anchor_r = None
        self.rope_len_l = 0
        self.rope_len_r = 0
        self.current_angle = 0.0
        self.swing_speed = 0.045
        self.is_charging = False
        self.charge_energy = 0.0
        self.blast_vx = 0.0
        self.blast_vy = 0.0
        self.blast_duration = 0
        self.sword_state = None  
        self.sword_timer = 0
        self.image = self.render_sprite()
        self.minecraft_head = self.generate_block_head()

    def generate_block_head(self):
        surf = pygame.Surface((32, 32))
        surf.fill((235, 195, 165))
        if self.hair_style == "MIKASA":
            pygame.draw.rect(surf, (20, 20, 20), (0, 0, 32, 14)) 
            pygame.draw.rect(surf, (150, 35, 30), (0, 26, 32, 6)) 
        elif self.hair_style == "ARMIN":
            pygame.draw.rect(surf, (230, 185, 65), (0, 0, 32, 14)) 
        else:
            pygame.draw.rect(surf, (55, 45, 40), (0, 0, 32, 12)) 
            pygame.draw.rect(surf, (45, 110, 65), (0, 26, 32, 6)) 
        pygame.draw.rect(surf, (50, 50, 55), (4, 15, 4, 4))
        pygame.draw.rect(surf, (50, 50, 55), (24, 15, 4, 4))
        return surf

    def stop_swinging(self):
        self.state = STATE_IDLE
        self.anchor_l = None
        self.anchor_r = None

    def handle_rope_input(self, keys, touch_points, camera, sw, sh, enemies):
        m_pressed = pygame.mouse.get_pressed()
        
        # 修正核心：如果觸控點列表不為空，取出第一個點；否則使用滑鼠座標
        if touch_points:
            pt = touch_points[0]
            active_input = True
        elif m_pressed[0]:
            pt = pygame.mouse.get_pos()
            active_input = True
        else:
            active_input = False

        if active_input:
            px, py = pt[0], pt[1]
            mx = (px / camera.zoom) + camera.x
            my = (py / camera.zoom) + camera.y
            
            # 手機端判定：點擊右下角按鈕觸發空中斬擊 (K)
            if px > sw - 130 and py > sh - 180:
                self.trigger_aerial_slash(enemies)
                return

            # 手機端與滑鼠判定：點擊右半邊螢幕發射鋼索
            if px > sw // 2:
                if py < sh // 2:
                    self.anchor_r = None
                    if not self.anchor_l:
                        self.anchor_l = (mx, my)
                        self.rope_len_l = math.hypot(self.anchor_l[0] - self.rect.centerx, self.anchor_l[1] - self.rect.centery)
                        self.current_angle = math.atan2(self.rect.centery - self.anchor_l[1], self.rect.centerx - self.anchor_l[0])
                        self.state = STATE_SWINGING
                else:
                    self.anchor_l = None
                    if not self.anchor_r:
                        self.anchor_r = (mx, my)
                        self.rope_len_r = math.hypot(self.anchor_r[0] - self.rect.centerx, self.anchor_r[1] - self.rect.centery)
                        self.current_angle = math.atan2(self.rect.centery - self.anchor_r[1], self.rect.centerx - self.anchor_r[0])
                        self.state = STATE_SWINGING
        else:
            if self.state == STATE_SWINGING: 
                self.state = STATE_IDLE
            self.anchor_l, self.anchor_r = None, None
# characters.py - Part 2: Virtual D-Pad Motion & Buddy System
    def handle_input(self, keys, touch_points, sw, sh):
        if self.state in [STATE_SWINGING, STATE_BLAST] or self.is_charging: return
        dx, dy = 0, 0
        touch_move = False
        
        for pt in touch_points:
            if pt < sw // 2:
                touch_move = True
                cx, cy = 100, sh - 100
                if pt < cx - 16: dx = -1; self.facing = LEFT
                elif pt > cx + 16: dx = 1; self.facing = RIGHT
                if pt < cy - 16: dy = -1; self.facing = UP
                elif pt > cy + 16: dy = 1; self.facing = DOWN

        if not touch_move:
            if keys[pygame.K_w] or keys[pygame.K_UP]: dy = -1; self.facing = UP
            elif keys[pygame.K_s] or keys[pygame.K_DOWN]: dy = 1; self.facing = DOWN
            elif keys[pygame.K_a] or keys[pygame.K_LEFT]: dx = -1; self.facing = LEFT
            elif keys[pygame.K_d] or keys[pygame.K_RIGHT]: dx = 1; self.facing = RIGHT
            
        if dx != 0 or dy != 0:
            self.state = STATE_WALK
            self.rect.x += dx * self.speed
            self.rect.y += dy * self.speed
        else: self.state = STATE_IDLE

    def update_swing_physics(self, enemies):
        if self.state == STATE_BLAST:
            self.rect.x += int(self.blast_vx)
            self.rect.y += int(self.blast_vy)
            self.blast_duration -= 1
            sr = pygame.Rect(self.rect.x - 20, self.rect.y - 20, 72, 72)
            for e in enemies:
                if not e.is_dead and sr.colliderect(e.rect): e.take_damage(100, is_neck_cut=False)
            if self.blast_duration <= 0: 
                self.state = STATE_IDLE
                self.sword_state = None
        elif self.state == STATE_SWINGING:
            aa = self.anchor_l if self.anchor_l else self.anchor_r
            sd = -1 if self.anchor_l else 1
            self.current_angle += self.swing_speed * sd
            al = self.rope_len_l if self.anchor_l else self.rope_len_r
            al = max(20, al - 0.3)
            if self.anchor_l: self.rope_len_l = al
            else: self.rope_len_r = al
            self.rect.centerx = int(aa + al * math.cos(self.current_angle))
            self.rect.centery = int(aa + al * math.sin(self.current_angle))
        
        if self.sword_state and self.state != STATE_BLAST:
            self.sword_timer -= 1
            if self.sword_timer <= 0: self.sword_state = None
        self.anim_timer += 1
        if self.anim_timer >= 6:
            self.anim_timer = 0
            self.anim_frame = (self.anim_frame + 1) % 8
        self.hair_sway = math.sin(self.anim_frame * 0.8) * 2.0 if self.state in [STATE_WALK, STATE_SWINGING] else 0.5
        self.image = self.render_sprite()

    def trigger_aerial_slash(self, enemies):
        self.sword_state = "SLASH"
        self.sword_timer = 12  
        sr = pygame.Rect(self.rect.x - 60, self.rect.y - 60, 152, 152)
        for e in enemies:
            nk = e.get_neck_rect()
            if not e.is_dead and (sr.colliderect(nk) or sr.colliderect(e.rect)):
                e.take_damage(50, is_neck_cut=sr.colliderect(nk))

    def render_sprite(self):
        surf = pygame.Surface((128, 128), pygame.SRCALPHA)
        bob = math.sin(self.anim_frame * 0.8) * 2 if self.state == STATE_WALK else 0
        cx, cy = 64, 64 + int(bob)
        pygame.draw.rect(surf, (200, 200, 205), (56, cy + 12, 6, 16)) 
        pygame.draw.rect(surf, (200, 200, 205), (66, cy + 12, 6, 16))
        pygame.draw.rect(surf, (55, 35, 30), (54, cy + 20, 8, 14), border_radius=1) 
        pygame.draw.rect(surf, (55, 35, 30), (64, cy + 20, 8, 14), border_radius=1)
        pygame.draw.rect(surf, (245, 245, 245), (54, cy, 20, 14)) 
        pygame.draw.rect(surf, (180, 115, 60), (52, cy, 5, 12), border_radius=1) 
        pygame.draw.rect(surf, (180, 115, 60), (71, cy, 5, 12), border_radius=1)
        if self.hair_style == "MIKASA":
            pygame.draw.rect(surf, (160, 30, 25), (54, cy - 2, 20, 5), border_radius=1)
            pygame.draw.polygon(surf, (130, 25, 20), [(54, cy + 2), (50, cy + 12), (58, cy + 4)])
            pygame.draw.rect(surf, (140, 140, 145), (46, cy + 5, 6, 14)) 
            pygame.draw.rect(surf, (140, 140, 145), (76, cy + 5, 6, 14))
        pygame.draw.circle(surf, (245, 215, 185), (cx, cy - 10), 10) 
        hc = (20, 20, 20) if self.hair_style == "MIKASA" else ((235, 190, 70) if self.hair_style == "ARMIN" else (60, 48, 42))
        pygame.draw.ellipse(surf, hc, (52 + int(self.hair_sway * 0.5), cy - 22, 24, 13)) 
        if self.hair_style == "MIKASA": 
            pygame.draw.line(surf, hc, (53, cy - 14), (53, cy - 4), 3)
            pygame.draw.line(surf, hc, (75, cy - 14), (75, cy - 4), 3)
        if self.sword_state == "SLASH":
            pygame.draw.line(surf, (240, 245, 255), (cx + 10, cy), (cx + 46, cy + 10), 6)
            if self.state == "BLAST": pygame.draw.line(surf, (240, 245, 255), (cx - 10, cy), (cx - 46, cy + 10), 6)
        return surf

class Buddy(Player):
    def __init__(self, x, y, hair_style="EREN"):
        super().__init__(x, y, hair_style)
        self.name = "Partner " + hair_style
        self.hp, self.speed = 100, 4

    def draw_buddy_hp(self, screen, camera):
        if self.hp <= 0: return
        pos = camera.apply(pygame.Rect(self.rect.x, self.rect.y - 14, self.rect.width, 6))
        pygame.draw.rect(screen, (80, 20, 20), (pos.x, pos.y, pos.width, 5))
        pygame.draw.rect(screen, (30, 190, 70), (pos.x, pos.y, int(pos.width * (self.hp / 100.0)), 5))

    def update_ai_with_strategy(self, enemies, base_hp):
        if self.hp <= 0: return 
        if self.sword_state:
            self.sword_timer = max(0, self.sword_timer - 1)
            if self.sword_timer <= 0: self.sword_state = None
            self.image = self.render_sprite()
            return
        ve = [e for e in enemies if not e.is_dead]
        if not ve:
            self.state = STATE_IDLE
            self.image = self.render_sprite()
            return
        te = min(ve, key=lambda e: math.hypot(e.rect.centerx - 2400, e.rect.centery - 1800)) if base_hp <= 50.0 else (min(ve, key=lambda e: e.rect.centerx) if "ARMIN" in self.name else min(ve, key=lambda e: -e.rect.centerx))
        if not te: return
        dst = math.hypot(te.rect.centerx - self.rect.centerx, te.rect.centery - self.rect.centery)
        if dst < 95:
            self.sword_state = "SLASH"
            self.sword_timer = 12
            self.state = STATE_IDLE
            nk = te.get_neck_rect()
            v_cut = math.hypot(self.rect.centerx - nk.centerx, self.rect.centery - nk.centery) < 65
            te.take_damage(35, is_neck_cut=v_cut)
        else:
            self.state = STATE_WALK
            dx = te.get_neck_rect().centerx - self.rect.centerx
            dy = te.get_neck_rect().centery - self.rect.centery
            mag = math.hypot(dx, dy)
            if mag > 0:
                self.rect.x += (dx / mag) * self.speed
                self.rect.y += (dy / mag) * self.speed
        for e in ve:
            if self.rect.colliderect(e.rect) and random.random() < 0.015: self.hp = max(0, self.hp - 5)
        self.anim_timer += 1
        if self.anim_timer >= 6:
            self.anim_timer = 0
            self.anim_frame = (self.anim_frame + 1) % 8
        self.image = self.render_sprite()
