# -*- coding: utf-8 -*-
# game_engine.py - Part 1: Camera Space & 3D Vector Menu Base
import pygame
import math
import random
from enemy import Enemy

class Camera:
    def __init__(self, width, height, map_w, map_h, zoom=2.0):
        self.width, self.height = width, height
        self.map_w, self.map_h = map_w, map_h
        self.zoom = zoom
        self.x, self.y = 0, 0

    def update(self, target_rect):
        self.x = target_rect.centerx - (self.width / 2) / self.zoom
        self.y = target_rect.centery - (self.height / 2) / self.zoom
        self.x = max(0, min(self.x, self.map_w - self.width / self.zoom))
        self.y = max(0, min(self.y, self.map_h - self.height / self.zoom))

    def apply(self, rect):
        return pygame.Rect(
            int((rect.x - self.x) * self.zoom), 
            int((rect.y - self.y) * self.zoom), 
            max(1, int(rect.width * self.zoom)), 
            max(1, int(rect.height * self.zoom))
        )

    def apply_surface(self, surface, pos):
        w = int(surface.get_width() * self.zoom)
        h = int(surface.get_height() * self.zoom)
        scaled_surf = pygame.transform.scale(surface, (w, h))
        rx = int((pos[0] - self.x) * self.zoom)
        ry = int((pos[1] - self.y) * self.zoom)
        return scaled_surf, (rx, ry)

class Menu3D:
    def __init__(self, screen_w, screen_h):
        self.screen_w, self.screen_h = screen_w, screen_h
        self.size, self.height = 110, 360 
        self.vertices = [
            [-self.size, -self.size, -self.size], [ self.size, -self.size, -self.size], 
            [ self.size, -self.size,  self.size], [-self.size, -self.size,  self.size], 
            [-self.size,  self.height, -self.size], [ self.size,  self.height, -self.size], 
            [ self.size,  self.height,  self.size], [-self.size,  self.height,  self.size]
        ]
        self.angle_x, self.angle_y, self.angle_z = 0.6, 0.4, 0.0
        self.is_transitioning, self.transition_progress = False, 0.0
        self.ui_state, self.envelope_open_progress = "LETTER", 0.0
        self.drop_timer, self.player_scale, self.player_landed = 0.0, 4.5, False
        self.blackhole_pulse = 0.0
        self.btn_start = pygame.Rect(screen_w // 2 - 100, screen_h - 120, 200, 50)
        self.slider_rect = pygame.Rect(screen_w // 2 - 100, screen_h - 180, 200, 16)
        self.volume = 0.5
        self.dragging_volume = False
        self.mouse_pos = (0, 0)
        self.config = {"buddy_system": True}

    def rotate_point(self, x, y, z, ax, ay, az):
        y1 = y * math.cos(ax) - z * math.sin(ax)
        z1 = y * math.sin(ax) + z * math.cos(ax)
        x2 = x * math.cos(ay) + z1 * math.sin(ay)
        z2 = -x * math.sin(ay) + z1 * math.cos(ay)
        rx = x2 * math.cos(az) - y1 * math.sin(az)
        ry = x2 * math.sin(az) + y1 * math.cos(az)
        return rx, ry, z2
# game_engine.py - Part 2: Menu3D Member Functions & HUD Classes
    def handle_input(self, event):
        if event.type == pygame.MOUSEMOTION: 
            self.mouse_pos = event.pos
            if self.dragging_volume:
                x_rel = event.pos[0] - self.slider_rect.x
                self.volume = max(0.0, min(x_rel / self.slider_rect.width, 1.0))
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.ui_state == "LETTER": 
                self.ui_state = "OPENING_LETTER"
                return {"action": "LETTER_OPENED"}
            elif not self.is_transitioning and self.ui_state == "MAIN":
                if self.slider_rect.inflate(10, 20).collidepoint(event.pos):
                    self.dragging_volume = True
                    x_rel = event.pos[0] - self.slider_rect.x
                    self.volume = max(0.0, min(x_rel / self.slider_rect.width, 1.0))
                elif self.btn_start.collidepoint(event.pos):
                    self.is_transitioning = True
                    return {"action": "START_CLICKED", "config": self.config}
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging_volume = False
        return None

    def draw_envelope(self, surface):
        paper_bg, shadow_line = (242, 233, 218), (65, 55, 45)
        surface.fill((215, 205, 190))
        pygame.draw.rect(surface, paper_bg, (20, 20, self.screen_w - 40, self.screen_h - 40))
        for y in range(25, self.screen_h - 25, 8):
            pygame.draw.circle(surface, shadow_line, (40, y), 2)
            pygame.draw.circle(surface, shadow_line, (self.screen_w - 40, y), 2)
        mid_y = int(self.screen_h * 0.45)
        if self.ui_state == "LETTER":
            points = [(20, 20), (self.screen_w // 2, mid_y), (self.screen_w - 20, 20)]
            pygame.draw.polygon(surface, paper_bg, points)
            pygame.draw.polygon(surface, shadow_line, points, 2)
        elif self.ui_state == "OPENING_LETTER":
            self.envelope_open_progress += 0.04
            if self.envelope_open_progress >= 1.0: 
                self.ui_state = "MAIN"
            flap_y = 20 - int((mid_y - 20) * self.envelope_open_progress)
            points = [(20, 20), (self.screen_w // 2, flap_y), (self.screen_w - 20, 20)]
            pygame.draw.polygon(surface, (230, 220, 200), points)
            pygame.draw.polygon(surface, shadow_line, points, 2)

    def draw_dropping_player(self, surface, cx, cy):
        if not self.player_landed:
            self.drop_timer += 0.02
            self.player_scale = max(1.0, 4.5 - (self.drop_timer * 2.2))
            if self.player_scale <= 1.0: 
                self.player_landed = True
        current_radius = int(12 * self.player_scale)
        rot_offset = self.drop_timer * 4.0
        px = cx + int(math.sin(rot_offset) * (40 * (self.player_scale - 1.0)))
        py = cy - 80 + int(self.drop_timer * 45 if not self.player_landed else 45)
        pygame.draw.circle(surface, (245, 215, 185), (px, py), current_radius)
        w_body = int(16 * self.player_scale)
        h_body = int(20 * self.player_scale)
        pygame.draw.rect(
            surface, (180, 115, 60),
            (px - int(8 * self.player_scale), py + current_radius, w_body, h_body),
            border_radius=2
        )
# game_engine.py - Part 3: Render Pipeline, Victory Elements & Game HUD Base
    def update_and_draw(self, surface):
        if self.ui_state in ["LETTER", "OPENING_LETTER"]:
            self.draw_envelope(surface)
            txt = pygame.font.Font(None, 36).render(
                "Click Letter Cover to Open", True, (80, 70, 60)
            )
            surface.blit(txt, txt.get_rect(center=(self.screen_w // 2, self.screen_h - 60)))
            return False

        center_x, center_y = self.screen_w // 2, self.screen_h // 2
        p = self.transition_progress
        surface.fill((10, 8, 12))
        self.blackhole_pulse += 0.05
        max_r = 320 + int(math.sin(self.blackhole_pulse) * 15)
        for r in range(max_r, 0, -25):
            alpha = int(120 * (1.0 - (r / max_r)))
            hole = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(hole, (30, 20, 45, alpha), (r, r), r)
            surface.blit(hole, (center_x - r, center_y - r))

        if not self.is_transitioning: 
            self.angle_x += 0.005
            self.angle_y += 0.010
        else: 
            self.transition_progress = min(1.0, self.transition_progress + 0.03)

        transformed = []
        base_fov = 400
        for vertex in self.vertices:
            rx, ry, rz = self.rotate_point(vertex[0], vertex[1], vertex[2], self.angle_x, self.angle_y, self.angle_z)
            scale = (base_fov / (base_fov + rz)) * (1.0 - p) + 1.8 * p
            transformed.append((int(rx * scale + center_x), int(ry * scale + center_y)))

        try:
            pygame.draw.polygon(surface, (140, 95, 75), [transformed[0], transformed[1], transformed[5], transformed[4]])
            pygame.draw.polygon(surface, (120, 80, 60), [transformed[1], transformed[2], transformed[6], transformed[5]])
            pygame.draw.polygon(surface, (100, 65, 50), [transformed[2], transformed[3], transformed[7], transformed[6]])
        except Exception: 
            pass

        self.draw_dropping_player(surface, center_x, center_y)
        if p < 1.0:
            t_surf = pygame.font.Font(None, 62).render("LOKI CITY DEFENSE", True, (255, 230, 180))
            surface.blit(t_surf, t_surf.get_rect(center=(self.screen_w // 2, 70)))
            if not self.is_transitioning:
                pygame.draw.rect(surface, (50, 45, 55), self.slider_rect, border_radius=4)
                fill_w = int(self.slider_rect.width * self.volume)
                pygame.draw.rect(
                    surface, (230, 180, 60),
                    (self.slider_rect.x, self.slider_rect.y, fill_w, self.slider_rect.height),
                    border_radius=4
                )
                handle_x = self.slider_rect.x + fill_w
                pygame.draw.circle(surface, (255, 240, 200), (handle_x, self.slider_rect.centery), 10)
                vol_lbl = pygame.font.Font(None, 24).render(
                    f"Music Volume: {int(self.volume * 100)}%", True, (220, 210, 200)
                )
                surface.blit(vol_lbl, vol_lbl.get_rect(center=(self.screen_w // 2, self.slider_rect.y - 20)))

                color = (240, 130, 150) if self.btn_start.collidepoint(self.mouse_pos) else (200, 90, 110)
                pygame.draw.rect(surface, color, self.btn_start, border_radius=10)
                txt = pygame.font.Font(None, 32).render("START DEFENSE", True, (255, 255, 255))
                surface.blit(txt, txt.get_rect(center=self.btn_start.center))
        return self.transition_progress >= 1.0

class TiramisuCake3D:
    def __init__(self, screen_w, screen_h): 
        self.screen_w = screen_w
        self.screen_h = screen_h
        
    def draw(self, surface, progress):
        cx = self.screen_w // 2
        cy = self.screen_h // 2
        rt = int(120 * progress)
        ht = int(90 * progress)
        for h in range(ht, 0, -1):
            sy = cy + h - (ht // 2)
            rect = pygame.Rect(cx - rt, sy - int(rt * 0.4), rt * 2, int(rt * 0.8))
            sc = (95, 60, 45) if h % 30 < 15 else (235, 215, 180)
            pygame.draw.ellipse(surface, sc, rect)
        tr = pygame.Rect(cx - rt, cy - (ht // 2) - int(rt * 0.4), rt * 2, int(rt * 0.8))
        pygame.draw.ellipse(surface, (115, 70, 50), tr)
        pygame.draw.ellipse(surface, (85, 45, 30), tr, 3) 
        can_x = cx
        can_y = cy - (ht // 2) - 10
        pygame.draw.line(surface, (100, 200, 255), (can_x, can_y), (can_x, can_y - 40), 6) 
        pygame.draw.line(surface, (255, 255, 255), (can_x, can_y), (can_x, can_y - 40), 2)
        fo = math.sin(pygame.time.get_ticks() * 0.02) * 2
        pygame.draw.circle(surface, (255, 140, 0), (int(can_x + fo), can_y - 48), 8)
        pygame.draw.circle(surface, (255, 230, 50), (int(can_x + fo), can_y - 46), 4)
        txt = pygame.font.Font(None, 62).render("HAPPY BIRTHDAY!", True, (255, 220, 100))
        surface.blit(txt, txt.get_rect(center=(cx, cy - 140)))

class GameHUD:
    def __init__(self): 
        self.font_small = pygame.font.Font(None, 18)
        self.font_medium = pygame.font.Font(None, 26)
        self.font_large = pygame.font.Font(None, 32)
# game_engine.py - Part 4: Game HUD Draw, Main Simulation & Environment
    def draw_all(self, screen, sw, sh, target, killed, base_hp, m_type, p_hp, partners, is_muted, show_enemy_hp, curr_zoom):
        rem = max(0, target - killed)
        mt = "GERMAN MEDIEVAL TOWN" if m_type == "CITY" else "WILD GIANT FOREST"
        ts = self.font_large.render(f"[{mt}] TITANS REMAINING: {rem}", True, (240, 230, 200))
        pygame.draw.rect(screen, (45, 40, 35), (8, 8, ts.get_width() + 16, 38), border_radius=4)
        screen.blit(ts, (16, 16))
        if m_type == "CITY":
            hc = (245, 70, 60) if base_hp <= 25 else (70, 240, 100)
            hs = self.font_large.render(f"WALL HEALTH: {int(max(0, base_hp))}%", True, hc)
            screen.blit(hs, hs.get_rect(bottomright=(sw - 20, sh - 20)))
        gs = self.font_medium.render("[WASD] Move | [I/O] Zoom | [Hold J/L] Hook | [K] Slash", True, (200, 200, 200))
        screen.blit(gs, (sw - gs.get_width() - 20, 18))
        
        # 【全新功能：左下角相機層級字樣顯示】
        z_modes = {1: "1/3 (CLOSE)", 2: "2/3 (NORMAL)", 3: "3/3 (FAR)"}
        z_str = f"[CAMERA: ZOOM {z_modes.get(curr_zoom, 'UNKNOWN')}]"
        z_surf = self.font_medium.render(z_str, True, (230, 220, 190))
        # 繪製灰色小底框確保字體清晰
        pygame.draw.rect(screen, (40, 35, 35), (8, sh - 45, z_surf.get_width() + 16, 32), border_radius=4)
        screen.blit(z_surf, (16, sh - 39))
        
        ib = pygame.Rect(sw - 50, 60, 36, 36)
        pygame.draw.rect(screen, (40, 35, 35), ib, border_radius=6)
        pygame.draw.rect(screen, (120, 110, 105), ib, 2, border_radius=6)
        
        if not is_muted:
            pygame.draw.polygon(screen, (240, 240, 245), [(sw - 42, 78), (sw - 34, 78), (sw - 26, 84), (sw - 26, 72)])
            pygame.draw.rect(screen, (240, 240, 245), (sw - 42, 75, 6, 6))
            pygame.draw.arc(screen, (240, 240, 245), (sw - 28, 72, 10, 12), -math.pi/3, math.pi/3, 2)
        else:
            pygame.draw.polygon(screen, (225, 90, 90), [(sw - 42, 78), (sw - 34, 78), (sw - 26, 84), (sw - 26, 72)])
            pygame.draw.rect(screen, (225, 90, 90), (sw - 42, 75, 6, 6))
            pygame.draw.line(screen, (240, 70, 70), (sw - 45, 65), (sw - 20, 91), 3)

        eye_b = pygame.Rect(sw - 95, 60, 36, 36)
        pygame.draw.rect(screen, (40, 35, 35), eye_b, border_radius=6)
        ec = (70, 210, 80) if show_enemy_hp else (150, 150, 150)
        pygame.draw.rect(screen, ec, eye_b, 2, border_radius=6)
        pygame.draw.ellipse(screen, ec, (sw - 91, 68, 28, 20), 2)
        pygame.draw.circle(screen, ec, (sw - 77, 78), 4 if show_enemy_hp else 2)
        if not show_enemy_hp:
            pygame.draw.line(screen, (240, 70, 70), (sw - 91, 64), (sw - 63, 92), 3)

        bg_w, bg_h = 580, 55
        hx = (sw - bg_w) // 2
        hy = sh - bg_h - 12
        bg = pygame.Surface((bg_w, bg_h), pygame.SRCALPHA)
        bg.fill((30, 25, 25, 210))
        screen.blit(bg, (hx, hy))
        pygame.draw.rect(screen, (110, 100, 90), (hx, hy, bg_w, bg_h), 2, border_radius=4)
        pl = self.font_medium.render("LILLY HP", True, (255, 255, 255))
        screen.blit(pl, (hx + 15, hy + 16))
        bx, by, bw, bh = hx + 95, hy + 20, 130, 14
        pygame.draw.rect(screen, (70, 20, 20), (bx, by, bw, bh))
        pygame.draw.rect(screen, (50, 210, 80), (bx, by, int(bw * (max(0, p_hp) / 100.0)), bh))
        pygame.draw.rect(screen, (160, 150, 140), (bx, by, bw, bh), 1)
        kl = self.font_large.render(f"KILLS: {killed}", True, (255, 215, 0))
        screen.blit(kl, (bx + bw + 15, hy + 14))
        bsx = bx + bw + 120
        for i, buddy in enumerate(partners):
            if buddy.hp > 0:
                b_y = hy + 8 + (i * 22)
                bn = "ARMIN" if "ARMIN" in buddy.name else "EREN"
                screen.blit(self.font_small.render(f"{bn}:", True, (220, 220, 220)), (bsx, b_y))
                bbw, bbh, bbx = 80, 8, bsx + 50
                pygame.draw.rect(screen, (60, 15, 15), (bbx, b_y + 4, bbw, bbh))
                pygame.draw.rect(screen, (30, 180, 220), (bbx, b_y + 4, int(bbw * (buddy.hp / 100.0)), bbh))
                pygame.draw.rect(screen, (100, 100, 100), (bbx, b_y + 4, bbw, bbh), 1)

def update_game_simulation(ctx, lilly, enemies, partners, g_vars, config):
    mw, mh = ctx["MAP_SIZE"]
    city_r = ctx["CITY_RECT"]
    sq_r = ctx["CENTER_SQUARE_RECT"]
    
    if g_vars["current_map"] == "CITY":
        if (lilly.rect.centerx < city_r.left - 2000 or lilly.rect.centerx > city_r.right + 2000 or 
                lilly.rect.centery < city_r.top - 2000 or lilly.rect.centery > city_r.bottom + 2000):
            g_vars["current_map"] = "FOREST"
            enemies.clear()
            lilly.stop_swinging()
            lilly.rect.center = (mw // 2, mh // 2)
            for b in partners: 
                b.rect.center = (mw // 2 + random.randint(-50, 50), mh // 2 + random.randint(-50, 50))
            for _ in range(12): 
                enemies.append(Enemy(random.randint(200, mw - 200), random.randint(200, 500), random.choice(["NORMAL", "COLOSSAL"])))
    
    elif g_vars["current_map"] == "FOREST":
        if (lilly.rect.centerx < 50 or lilly.rect.centerx > mw - 50 or lilly.rect.centery < 50 or lilly.rect.centery > mh - 50):
            g_vars["current_map"] = "CITY"
            enemies.clear()
            lilly.stop_swinging()
            lilly.rect.center = (sq_r.centerx, sq_r.centery)
            for b in partners: 
                b.rect.center = (sq_r.centerx + random.randint(-40, 40), sq_r.centery + random.randint(-40, 40))
            for _ in range(8):
                enemies.append(Enemy(random.randint(city_r.left - 400, city_r.right + 400), random.randint(city_r.top - 400, city_r.bottom + 400), random.choice(["NORMAL", "COLOSSAL"])))

    if g_vars["enemies_killed"] >= g_vars["total_spawn_target"] and len(enemies) == 0: 
        return "VICTORY"
    if lilly.hp <= 0: 
        return "RESET_TO_MENU"
    partners[:] = [b for b in partners if b.hp > 0]
    
    if g_vars["current_map"] == "CITY" and g_vars["base_hp"] <= 0 and not g_vars["breach_active"]:
        g_vars["breach_active"] = True
        g_vars["breacher"] = min(enemies, key=lambda e: math.hypot(e.rect.centerx - sq_r.centerx, e.rect.centery - sq_r.centery)) if enemies else Enemy(2400, 1800, "COLOSSAL")
    
    if not g_vars["breach_active"]:
        g_vars["game_timer"] += 1
        si = max(45, 190 - int(g_vars["game_timer"] / 22.0))
        g_vars["enemy_spawn_timer"] += 1
        if g_vars["enemy_spawn_timer"] >= si and (len(enemies) + g_vars["enemies_killed"] < g_vars["total_spawn_target"]):
            g_vars["enemy_spawn_timer"] = 0
            if g_vars["current_map"] == "CITY":
                sd = random.choice(["TOP", "BOTTOM", "LEFT", "RIGHT"])
                ex = random.randint(0, mw) if sd in ["TOP", "BOTTOM"] else (-60 if sd == "LEFT" else mw + 60)
                ey = random.randint(0, mh) if sd in ["LEFT", "RIGHT"] else (-60 if sd == "TOP" else mh + 60)
            else:
                ex, ey = random.randint(100, mw - 100), random.randint(100, 500)
            enemies.append(Enemy(ex, ey, "COLOSSAL" if random.random() < 0.15 else "NORMAL"))
    else:
        if g_vars["current_map"] == "CITY" and g_vars["breacher"] and g_vars["breacher"].ai_state == "BREACHED":
            if g_vars["breach_hole_pos"] is None: 
                g_vars["breach_hole_pos"] = g_vars["breacher"].rect.center
            g_vars["breach_cooldown"] += 1
            if g_vars["breach_cooldown"] > 150: 
                return "RESET_TO_MENU"
    return "CONTINUE"

def draw_detailed_house(surface, rect):
    pygame.draw.rect(surface, (242, 236, 222), rect)
    pygame.draw.rect(surface, (55, 42, 34), rect, 2)
    pygame.draw.line(surface, (55, 42, 34), rect.topleft, rect.bottomright, 3)
    pygame.draw.line(surface, (55, 42, 34), rect.topright, rect.bottomleft, 3)
    pygame.draw.line(surface, (55, 42, 34), rect.midleft, rect.midright, 2)
    pygame.draw.line(surface, (55, 42, 34), rect.midtop, rect.midbottom, 2)
    rf = [(rect.left - 6, rect.top), (rect.centerx, rect.top - 24), (rect.right + 6, rect.top)]
    pygame.draw.polygon(surface, (150, 52, 38), rf)
    pygame.draw.polygon(surface, (45, 35, 30), rf, 2)
    pygame.draw.rect(surface, (95, 65, 50), (rect.centerx - 8, rect.bottom - 16, 16, 16))

def draw_giant_tree(surface, camera, x, y):
    pygame.draw.rect(surface, (70, 45, 30), camera.apply(pygame.Rect(x - 25, y, 50, 180)))
    fol = camera.apply(pygame.Rect(x - 100, y - 120, 200, 140))
    pygame.draw.ellipse(surface, (30, 95, 50), fol)
    pygame.draw.ellipse(surface, (20, 70, 35), fol, 2)
