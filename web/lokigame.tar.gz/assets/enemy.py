# -*- coding: utf-8 -*-
# enemy.py - Part 1: Titan AI, Motion Dynamics & Numerical Updates
import pygame
import math
import random

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, variant="NORMAL"):
        super().__init__()
        self.variant = variant
        # 【更新修正】一般巨人血量改為 100，超大型巨人改為 500
        self.hp = 500 if variant == "COLOSSAL" else 100
        self.max_hp = self.hp
        self.is_dead = False
        
        self.width = 110 if variant == "COLOSSAL" else 75
        self.height = 360 if variant == "COLOSSAL" else 240
        self.rect = pygame.Rect(x, y, self.width, self.height)
        
        self.x = float(x)
        self.y = float(y)
        self.attack_cooldown = 0
        self.dodge_cooldown = 0
        
        self.rush_timer = 0
        self.rush_duration = 0
        self.anim_phase = random.uniform(0, math.pi * 2)
        self.ai_state = "NORMAL"
        self.minecraft_head = self.generate_block_head()

    def generate_block_head(self):
        surf = pygame.Surface((48, 48))
        c = (160, 30, 20) if self.variant == "COLOSSAL" else (110, 45, 35)
        surf.fill(c) 
        pygame.draw.rect(surf, (75, 25, 20), (0, 0, 48, 48), 4)
        return surf

    def get_neck_rect(self):
        return pygame.Rect(self.rect.centerx - 20, self.rect.y + 15, 40, 35)

    def take_damage(self, amount, is_neck_cut=False):
        if is_neck_cut: 
            self.hp -= (amount * 2.5)
        else: 
            self.hp -= amount
        if self.hp <= 0:
            self.hp = 0
            self.is_dead = True

    def update_ai(self, br, p_obj, speed_mod, curr_bhp, br_act=False, is_br=False, p_sw=False):
        if self.is_dead: 
            return curr_bhp
        cx, cy = br.center
        p_rect = p_obj.rect
        self.anim_phase += 0.16
        if self.dodge_cooldown > 0: 
            self.dodge_cooldown -= 1

        if self.variant == "COLOSSAL":
            self.rush_timer += 1
            if self.rush_timer >= 5400:
                self.ai_state = "RUSHING"
                self.rush_timer = 0
                self.rush_duration = 180 

        if self.ai_state == "RUSHING":
            self.rush_duration -= 1
            if self.rush_duration <= 0: 
                self.ai_state = "NORMAL"
            dx = cx - self.rect.centerx
            dy = cy - self.rect.centery
            dist = math.hypot(dx, dy)
            if dist > 0:
                self.x += (dx / dist) * 6.5
                self.y += (dy / dist) * 6.5
                self.rect.x, self.rect.y = int(self.x), int(self.y)
            # 【更新修正】當玩家處於雙刀蓄力衝刺殺狀態時，免疫一般巨人的碰撞傷害
            if self.rect.colliderect(p_rect) and self.attack_cooldown <= 0:
                if p_obj.state != "BLAST":
                    p_obj.hp = max(0, p_obj.hp - 20)
                    self.attack_cooldown = 40
            return curr_bhp

        dp = math.hypot(p_rect.centerx - self.rect.centerx, p_rect.centery - self.rect.centery)
        if p_sw and dp < 220 and self.dodge_cooldown == 0:
            dx = p_rect.centerx - self.rect.centerx
            dy = p_rect.centery - self.rect.centery
            norm = math.hypot(dx, dy)
            if norm > 0:
                self.x += (-dy / norm) * 35.0
                self.y += (dx / norm) * 35.0
                self.dodge_cooldown = 140

        if br_act and is_br:
            dx = cx - self.rect.centerx
            dy = cy - self.rect.centery
            dist = math.hypot(dx, dy)
            if dist < 40: 
                self.ai_state = "BREACHED"
            else:
                self.x += (dx / dist) * 15
                self.y += (dy / dist) * 15
                self.rect.x, self.rect.y = int(self.x), int(self.y)
            return curr_bhp

        if self.attack_cooldown > 0: 
            self.attack_cooldown -= 1
        dx = cx - self.rect.centerx
        dy = cy - self.rect.centery
        dist = math.hypot(dx, dy)

        if self.rect.colliderect(br):
            if self.attack_cooldown <= 0:
                curr_bhp -= 15.0 if self.variant == "COLOSSAL" else 6.0
                self.attack_cooldown = 60 
        elif self.rect.colliderect(p_rect):
            if self.attack_cooldown <= 0:
                # 【更新修正】當玩家處於雙刀蓄力衝刺殺狀態時，免疫一般巨人的碰撞傷害
                if p_obj.state != "BLAST":
                    p_obj.hp = max(0, p_obj.hp - 10)
                    self.attack_cooldown = 70
        elif dist > 0:
            bs = 2.0 if self.variant == "COLOSSAL" else 0.4
            cs = min(bs + (speed_mod * 1.2), 3.5) 
            self.x += (dx / dist) * cs
            self.y += (dy / dist) * cs
            self.rect.x, self.rect.y = int(self.x), int(self.y)

        return curr_bhp

    def draw(self, surface, camera, show_hp_bar=True):
        if self.is_dead: 
            return
        sr = camera.apply(self.rect)
        z = camera.zoom
        ll = math.sin(self.anim_phase) * 18 * z
        rl = math.sin(self.anim_phase + math.pi) * 18 * z
        bc = (125, 55, 45) if self.variant != "COLOSSAL" else (180, 40, 30)
        if self.ai_state == "RUSHING": 
            bc = (255, 10, 10)
        
        pygame.draw.line(surface, (85, 35, 25), (sr.centerx - int(12*z), sr.y + int(self.height*0.6*z)), (sr.centerx - int(18*z) + int(ll*0.3), sr.bottom), max(1, int(8*z)))
        pygame.draw.line(surface, (85, 35, 25), (sr.centerx + int(12*z), sr.y + int(self.height*0.6*z)), (sr.centerx + int(18*z) + int(rl*0.3), sr.bottom), max(1, int(8*z)))
        pygame.draw.rect(surface, bc, pygame.Rect(sr.x + int(6*z), sr.y + int(40*z), sr.width - int(12*z), int(self.height * 0.45 * z)), border_radius=int(4*z))
        pygame.draw.circle(surface, (160, 85, 75), (sr.centerx, sr.y + int(20*z)), max(1, int(18*z)))
        
        # 【更新修正】依據 HUD 控制開關決定是否顯示帶數字的精確血條
        if show_hp_bar:
            pygame.draw.rect(surface, (50, 50, 55), pygame.Rect(sr.x, sr.y - 22, sr.width, 10))
            hp_color = (230, 20, 30) if self.variant == "COLOSSAL" else (50, 220, 80)
            pygame.draw.rect(surface, hp_color, pygame.Rect(sr.x, sr.y - 22, int(sr.width * (self.hp / self.max_hp)), 10))
            pygame.draw.rect(surface, (200, 200, 200), pygame.Rect(sr.x, sr.y - 22, sr.width, 10), 1)
            
            font = pygame.font.Font(None, max(12, int(14 * z)))
            hp_txt = font.render(f"{int(self.hp)}/{int(self.max_hp)}", True, (255, 255, 255))
            tx = sr.x + (sr.width // 2) - (hp_txt.get_width() // 2)
            ty = sr.y - 21
            surface.blit(hp_txt, (tx, ty))
